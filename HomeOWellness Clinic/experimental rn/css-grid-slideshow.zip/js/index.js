$('.gallery div').on('click', function(e){
  $(this).toggleClass('lightbox');
  $(window).scrollTop(0);
});